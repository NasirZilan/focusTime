export const colors={
white: '#F9F5EB',
darkBlue: '#252250',
progressBar: '#5E84E2'
}
